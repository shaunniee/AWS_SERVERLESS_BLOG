const { DynamoDBClient, PutItemCommand, GetItemCommand, ScanCommand, UpdateItemCommand, DeleteItemCommand } = require("@aws-sdk/client-dynamodb");
const { randomUUID } = require("crypto");

const client = new DynamoDBClient({});
const TABLE = process.env.POSTS_TABLE;

exports.handler = async (event) => {
  try {
    const method = event.httpMethod;
    const path = event.resource; // use API Gateway resource
    const id = event.pathParameters ? event.pathParameters.id : null;
    let body = event.body ? JSON.parse(event.body) : null;

    // CREATE POST
    if (method === "POST" && path === "/posts") {
      const item = {
        PostID: { S: randomUUID() },
        Title: { S: body.title },
        Content: { S: body.content },
        AuthorID: { S: body.authorId },
        Status: { S: "draft" },
        CreatedAt: { N: Date.now().toString() }
      };

      await client.send(new PutItemCommand({ TableName: TABLE, Item: item }));
      return { statusCode: 201, body: JSON.stringify(item) };
    }

    // GET ALL POSTS
    if (method === "GET" && path === "/posts") {
      const data = await client.send(new ScanCommand({ TableName: TABLE }));
      return { statusCode: 200, body: JSON.stringify(data.Items) };
    }

    // GET POST BY ID
    if (method === "GET" && path === "/posts/{id}") {
      const data = await client.send(new GetItemCommand({
        TableName: TABLE,
        Key: { PostID: { S: id } }
      }));

      if (!data.Item) return { statusCode: 404, body: "Post not found" };
      return { statusCode: 200, body: JSON.stringify(data.Item) };
    }

    // UPDATE POST
    if (method === "PUT" && path === "/posts/{id}") {
      const updateParams = {
        TableName: TABLE,
        Key: { PostID: { S: id } },
        UpdateExpression: "SET Title = :t, Content = :c",
        ExpressionAttributeValues: {
          ":t": { S: body.title },
          ":c": { S: body.content }
        },
        ReturnValues: "ALL_NEW"
      };

      const updated = await client.send(new UpdateItemCommand(updateParams));
      return { statusCode: 200, body: JSON.stringify(updated.Attributes) };
    }

    // DELETE POST
    if (method === "DELETE" && path === "/posts/{id}") {
      await client.send(new DeleteItemCommand({
        TableName: TABLE,
        Key: { PostID: { S: id } }
      }));
      return { statusCode: 204, body: "" };
    }

    return { statusCode: 400, body: "Unsupported method or path" };

  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ message: err.message }) };
  }
};